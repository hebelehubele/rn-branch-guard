#!/bin/sh

CHANGED=$(git diff --name-only HEAD@{1} HEAD | grep -E "package.json|package-lock.json|yarn.lock|pnpm-lock.yaml")

if [ -n "$CHANGED" ]; then
  echo ""
  echo "📦 Dependency files changed between branches."
  echo "⚠️ Run your package manager install command."
  echo "   Examples: npm install / yarn install / pnpm install"
  echo ""
fi